	<div class="footer-wrap bg-white pd-20 mb-20 border-radius-5 box-shadow">
		DeskApp - Bootstrap 4 Admin Template By <a href="https://github.com/dropways" target="_blank">Ankit Hingarajiya</a>
	</div>