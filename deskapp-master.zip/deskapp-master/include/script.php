	<!-- js -->
	<script src="vendors/scripts/script.js"></script>